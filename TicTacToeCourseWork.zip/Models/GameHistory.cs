using System;
namespace TicTacToeCourseWork.Models
{
    public class GameHistory
    {
        public string Username { get; set; }
        public string Result { get; set; }
        public DateTime Date { get; set; }
    }
}