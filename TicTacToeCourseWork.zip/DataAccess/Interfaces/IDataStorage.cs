using System.Collections.Generic;
using TicTacToeCourseWork.Models;

namespace TicTacToeCourseWork.DataAccess.Interfaces
{
    public interface IDataStorage
    {
        User GetUser(string username);
        void AddUser(User user);
        void UpdateUser(User user);
        List<GameHistory> GetHistory(string username);
        void AddHistory(GameHistory history);
        List<User> GetAllUsers();
    }
}