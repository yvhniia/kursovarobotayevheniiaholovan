using System.Collections.Generic;
using System.Linq;
using TicTacToeCourseWork.DataAccess.Interfaces;
using TicTacToeCourseWork.Models;

namespace TicTacToeCourseWork.DataAccess
{
    public class InMemoryDatabase : IDataStorage
    {
        private readonly List<User> users = new();
        private readonly List<GameHistory> history = new();

        public User GetUser(string username) => users.FirstOrDefault(u => u.Username == username);
        public void AddUser(User user) => users.Add(user);
        public void UpdateUser(User user) { }
        public List<GameHistory> GetHistory(string username) => history.Where(h => h.Username == username).ToList();
        public void AddHistory(GameHistory game) => history.Add(game);
        public List<User> GetAllUsers() => users.OrderByDescending(u => u.Rating).ToList();
    }
}