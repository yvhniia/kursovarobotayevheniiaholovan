using TicTacToeCourseWork.Models;

namespace TicTacToeCourseWork.BusinessLogic.Interfaces
{
    public interface IGameService
    {
        void Play(User user);
    }
}