using System;
using TicTacToeCourseWork.BusinessLogic.Interfaces;
using TicTacToeCourseWork.DataAccess.Interfaces;
using TicTacToeCourseWork.Models;

namespace TicTacToeCourseWork.BusinessLogic.Services
{
    public class TicTacToeGameService : IGameService
    {
        private readonly IDataStorage database;
        private char[,] board = new char[3,3];

        public TicTacToeGameService(IDataStorage db) => database = db;

        public void Play(User user)
        {
            InitializeBoard();
            char current = 'X';
            while (true)
            {
                Console.Clear();
                DrawBoard();
                Console.WriteLine($"Хід гравця: {current}");
                Console.Write("Рядок (0-2): "); int r = int.Parse(Console.ReadLine());
                Console.Write("Колонка (0-2): "); int c = int.Parse(Console.ReadLine());
                if (board[r,c] != ' ') continue;
                board[r,c] = current;
                if (CheckWin(current)) { user.UpdateRating(10); database.AddHistory(new GameHistory{Username=user.Username, Result="Перемога", Date=DateTime.Now}); break; }
                if (IsDraw()) { database.AddHistory(new GameHistory{Username=user.Username, Result="Нічия", Date=DateTime.Now}); break; }
                current = current=='X'?'O':'X';
            }
            Console.ReadKey();
        }

        private void InitializeBoard() { for(int i=0;i<3;i++) for(int j=0;j<3;j++) board[i,j]=' '; }
        private void DrawBoard() { for(int i=0;i<3;i++){ Console.WriteLine($" {board[i,0]} | {board[i,1]} | {board[i,2]} "); if(i<2) Console.WriteLine("---+---+---");}}
        private bool CheckWin(char p){for(int i=0;i<3;i++) if(board[i,0]==p&&board[i,1]==p&&board[i,2]==p) return true; for(int i=0;i<3;i++) if(board[0,i]==p&&board[1,i]==p&&board[2,i]==p) return true; if(board[0,0]==p&&board[1,1]==p&&board[2,2]==p) return true; if(board[0,2]==p&&board[1,1]==p&&board[2,0]==p) return true; return false;}
        private bool IsDraw(){foreach(var cell in board) if(cell==' ') return false; return true;}
    }
}