using TicTacToeCourseWork.BusinessLogic.Interfaces;
using TicTacToeCourseWork.DataAccess.Interfaces;
using TicTacToeCourseWork.Models;

namespace TicTacToeCourseWork.BusinessLogic.Services
{
    public class AuthService : IAuthService
    {
        private readonly IDataStorage database;
        public AuthService(IDataStorage db) => database = db;

        public User Register(string username, string password)
        {
            if (database.GetUser(username) != null) return null;
            var user = new User(username, password);
            database.AddUser(user);
            return user;
        }

        public User Login(string username, string password)
        {
            var user = database.GetUser(username);
            return (user != null && user.CheckPassword(password)) ? user : null;
        }
    }
}