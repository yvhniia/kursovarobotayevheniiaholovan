using System;
using TicTacToeCourseWork.BusinessLogic.Interfaces;
using TicTacToeCourseWork.BusinessLogic.Services;
using TicTacToeCourseWork.DataAccess;
using TicTacToeCourseWork.DataAccess.Interfaces;
using TicTacToeCourseWork.Models;

namespace TicTacToeCourseWork.UI
{
    class Program
    {
        static void Main()
        {
            IDataStorage db = new InMemoryDatabase();
            IAuthService auth = new AuthService(db);
            IGameService game = new TicTacToeGameService(db);

            User currentUser = null;
            while(true)
            {
                Console.Clear();
                Console.WriteLine("1. Реєстрація");
                Console.WriteLine("2. Вхід");
                Console.WriteLine("3. Рейтинг");
                Console.WriteLine("0. Вихід");
                string choice = Console.ReadLine();
                if(choice=="1") { Console.Write("Логін: "); string u=Console.ReadLine(); Console.Write("Пароль: "); string p=Console.ReadLine(); currentUser=auth.Register(u,p); }
                else if(choice=="2") { Console.Write("Логін: "); string u=Console.ReadLine(); Console.Write("Пароль: "); string p=Console.ReadLine(); currentUser=auth.Login(u,p); }
                else if(choice=="3") { foreach(var u in db.GetAllUsers()) Console.WriteLine($"{u.Username} - {u.Rating}"); Console.ReadKey(); }
                else if(choice=="0") return;
                if(currentUser!=null) { game.Play(currentUser); currentUser=null; }
            }
        }
    }
}